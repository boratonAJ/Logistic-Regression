## 2.1 What is R?

R is a system for statistical computation and graphics.  It consists of a
language plus a run-time environment with graphics, a debugger, access to
certain system functions, and the ability to run programs stored in script
files.
